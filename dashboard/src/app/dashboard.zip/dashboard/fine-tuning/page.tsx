'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/contexts/ThemeContext';
import { PlusCircle, RefreshCw } from 'lucide-react';
import Button from '@/components/ui/Button';
import TrainingJobList from '@/components/fine-tuning/TrainingJobList';
import ResourceMonitor from '@/components/fine-tuning/ResourceMonitor';
import CreateJobModal from '@/components/fine-tuning/CreateJobModal';
import { getFineTuningJobs, mockJobs } from '@/dashboard-api/fine-tuning-api';
import { getModels } from '@/dashboard-api/model-api';
import { getDatasets } from '@/dashboard-api/dataset-api';
import { FineTuningJob, JobStatus } from '@/types/fine-tuning';
import { Model, ModelTaskType, ModelTier, ModelType, ModelFramework, ModelStatus } from '@/dashboard-api/model-api';
import { Dataset, DatasetType, DatasetFormat, DatasetSource, DatasetStatus, DatasetPrivacy } from '@/dashboard-api/dataset-api';

const mockModels: Model[] = [
  { 
    id: 'gpt-4',
    name: 'GPT-4',
    displayName: 'GPT-4',
    version: '1.0.0',
    modelType: ModelType.LLM,
    framework: ModelFramework.TRANSFORMERS,
    taskType: ModelTaskType.TEXT_GENERATION,
    tier: ModelTier.PRO,
    description: 'Advanced language model for text generation',
    parameters: 175_000_000_000,
    modelSize: 350,
    license: 'proprietary',
    author: 'OpenAI',
    tags: ['language-model', 'text-generation'],
    status: ModelStatus.ACTIVE,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metrics: {
      accuracy: 0.95,
      latency: 100,
      throughput: 1000,
      memoryUsage: 40000,
      gpuUsage: 80
    },
    pricing: {
      pricePerRequest: 0.01,
      pricePerToken: 0.0001,
      freeQuota: 1000
    },
    architecture: {
      framework: 'transformers',
      layers: 96,
      attentionHeads: 96,
      contextWindow: 8192,
      trainingData: 'Mixed internet data'
    },
    resourceRequirements: {
      minCPU: '8 cores',
      minMemory: '16GB',
      recommendedGPU: 'NVIDIA A100'
    },
    documentation: {
      technicalDocs: 'https://docs.example.com/gpt4',
      examples: ['https://examples.com/gpt4/1'],
      papers: ['https://arxiv.org/abs/example']
    }
  },
  {
    id: 'bert-base',
    name: 'BERT Base',
    displayName: 'BERT Base',
    version: '1.0.0',
    modelType: ModelType.LLM,
    framework: ModelFramework.TRANSFORMERS,
    taskType: ModelTaskType.CLASSIFICATION,
    tier: ModelTier.PRO,
    description: 'Base BERT model for classification tasks',
    parameters: 110_000_000,
    modelSize: 440,
    license: 'apache-2.0',
    author: 'Google Research',
    tags: ['language-model', 'classification'],
    status: ModelStatus.ACTIVE,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metrics: {
      accuracy: 0.89,
      latency: 50,
      throughput: 2000,
      memoryUsage: 20000,
      gpuUsage: 60
    },
    pricing: {
      pricePerRequest: 0.005,
      pricePerToken: 0.00005,
      freeQuota: 2000
    },
    architecture: {
      framework: 'transformers',
      layers: 12,
      attentionHeads: 12,
      contextWindow: 512,
      trainingData: 'Wikipedia and BookCorpus'
    },
    resourceRequirements: {
      minCPU: '4 cores',
      minMemory: '8GB',
      recommendedGPU: 'NVIDIA V100'
    },
    documentation: {
      technicalDocs: 'https://docs.example.com/bert',
      examples: ['https://examples.com/bert/1'],
      papers: ['https://arxiv.org/abs/1810.04805']
    }
  },
];

const mockDatasets: Dataset[] = [
  {
    id: 'customer-support',
    name: 'Customer Support',
    description: 'Customer support conversations dataset',
    type: DatasetType.Text,
    format: DatasetFormat.JSONL,
    source: DatasetSource.Upload,
    size: 1024 * 1024 * 100, // 100MB
    itemCount: 50000,
    privacy: DatasetPrivacy.Private,
    status: DatasetStatus.Ready,
    tags: ['support', 'customer-service', 'chat'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      language: 'en',
      domain: 'customer-service'
    }
  },
  {
    id: 'sentiment-analysis',
    name: 'Sentiment Analysis',
    description: 'Sentiment analysis dataset',
    type: DatasetType.Text,
    format: DatasetFormat.JSONL,
    source: DatasetSource.Upload,
    size: 1024 * 1024 * 50, // 50MB
    itemCount: 25000,
    privacy: DatasetPrivacy.Private,
    status: DatasetStatus.Ready,
    tags: ['sentiment', 'classification'],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    metadata: {
      language: 'en',
      domain: 'sentiment'
    }
  },
];

export default function FineTuningPage() {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [jobs, setJobs] = useState<FineTuningJob[]>([]);
  const [models, setModels] = useState<Model[]>([]);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      if (process.env.NODE_ENV === 'development') {
        // Use mock data in development
        setJobs(mockJobs);
        setModels(mockModels);
        setDatasets(mockDatasets);
      } else {
        // Fetch real data in production
        const [jobsResponse, modelsResponse, datasetsResponse] = await Promise.all([
          getFineTuningJobs(),
          getModels({ taskType: [ModelTaskType.TEXT_GENERATION], tier: [ModelTier.PRO] }),
          getDatasets(),
        ]);

        // Map API response to expected types
        const mappedJobs: FineTuningJob[] = jobsResponse.items.map(job => ({
          ...job,
          status: JobStatus[job.status.toUpperCase() as keyof typeof JobStatus]
        }));

        setJobs(mappedJobs);
        setModels(modelsResponse.items);
        setDatasets(datasetsResponse.data || []); // Handle potential undefined data
      }
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load fine-tuning data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#00cbdd]" />
      </div>
    );
  }

  if (error) {
    return (
      <div className={`p-6 rounded-lg border text-center ${
        isDark 
          ? 'bg-red-500/10 border-red-500/30 text-red-400' 
          : 'bg-red-50 border-red-200 text-red-600'
      }`}>
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className={`text-2xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Fine-tuning
          </h1>
          <p className={`mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            Train custom models on your data
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            onClick={handleRefresh}
            variant="outline"
            disabled={refreshing}
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
          <Button
            onClick={() => setIsModalOpen(true)}
            className="bg-gradient-to-r from-[#00cbdd] to-[#00cbdd]/70 hover:from-[#00cbdd]/90 hover:to-[#00cbdd]/60"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            New Training Job
          </Button>
        </div>
      </div>

      {/* Resource Monitor */}
      <ResourceMonitor
        gpuHoursUsed={150}
        gpuHoursTotal={500}
        activeJobs={jobs.filter(job => job.status === JobStatus.RUNNING).length}
        maxJobs={10}
        gpuTypes={[
          { type: 'A100', available: 4, allocated: 4, total: 8 },
          { type: 'V100', available: 6, allocated: 6, total: 12 },
        ]}
      />

      {/* Training Jobs List */}
      <TrainingJobList
        initialJobs={jobs}
        availableModels={models}
        availableDatasets={datasets}
      />

      {/* Create Job Modal */}
      <CreateJobModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          fetchData();
        }}
        availableModels={models}
        availableDatasets={datasets}
      />
    </div>
  );
} 