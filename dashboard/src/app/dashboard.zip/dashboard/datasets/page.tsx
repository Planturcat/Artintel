"use client";

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/contexts/ThemeContext';
import {
  Upload,
  Database,
  Cloud,
  FileText,
  Search,
  Filter,
  Grid,
  List,
  Plus,
  RefreshCw,
  SlidersHorizontal
} from 'lucide-react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import DatasetCard from '@/components/datasets/DatasetCard';
import UploadModal from '@/components/datasets/UploadModal';
import CloudStorageModal from '@/components/datasets/CloudStorageModal';
import DatabaseModal from '@/components/datasets/DatabaseModal';
import { datasetService } from '@/services/datasetService';
import { CloudStorageConfig, DatabaseConfig } from '@/types/dataset';

// Mock data for testing
const mockDatasets = [
  {
    id: '1',
    name: 'Training Dataset 2023',
    description: 'Main training dataset for language models',
    type: 'Training',
    size: 1024 * 1024 * 500, // 500MB
    format: 'CSV',
    lastModified: new Date().toISOString(),
    tags: ['training', 'language', '2023'],
    source: 'local' as const,
    status: 'ready' as const
  },
  {
    id: '2',
    name: 'Validation Data Q4',
    description: 'Quarterly validation dataset for model evaluation',
    type: 'Validation',
    size: 1024 * 1024 * 200, // 200MB
    format: 'JSON',
    lastModified: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    tags: ['validation', 'quarterly'],
    source: 'cloud' as const,
    status: 'ready' as const
  },
  {
    id: '3',
    name: 'Test Dataset Beta',
    description: 'Beta testing dataset for new model features',
    type: 'Testing',
    size: 1024 * 1024 * 100, // 100MB
    format: 'CSV',
    lastModified: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['testing', 'beta'],
    source: 'database' as const,
    status: 'processing' as const
  }
];

export default function DatasetsPage() {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [datasets, setDatasets] = useState(mockDatasets);
  const [filteredDatasets, setFilteredDatasets] = useState(mockDatasets);
  const [isCloudModalOpen, setIsCloudModalOpen] = useState(false);
  const [isDatabaseModalOpen, setIsDatabaseModalOpen] = useState(false);
  
  // Filter datasets based on search query
  useEffect(() => {
    const filtered = datasets.filter(dataset => 
      dataset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dataset.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dataset.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    setFilteredDatasets(filtered);
  }, [searchQuery, datasets]);

  const handleUpload = async (files: File[], metadata: any) => {
    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Create new dataset entries
    const newDatasets = files.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      description: metadata.description,
      type: 'Training',
      size: file.size,
      format: file.name.split('.').pop()?.toUpperCase() || 'UNKNOWN',
      lastModified: new Date().toISOString(),
      tags: metadata.tags,
      source: 'local' as const,
      status: 'processing' as const
    }));
    
    setDatasets(prev => [...newDatasets, ...prev]);
  };

  const handleCloudConnect = async (config: CloudStorageConfig) => {
    try {
      // In development, use mock service
      const newDataset = await datasetService.mockConnectCloudStorage(config);
      setDatasets(prev => [newDataset, ...prev]);
    } catch (error: any) {
      console.error('Failed to connect to cloud storage:', error);
      // You might want to show an error toast here
    }
  };

  const handleDatabaseConnect = async (config: DatabaseConfig) => {
    try {
      // In development, use mock service
      const newDataset = await datasetService.mockConnectDatabase(config);
      setDatasets(prev => [newDataset, ...prev]);
    } catch (error: any) {
      console.error('Failed to connect to database:', error);
      // You might want to show an error toast here
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await datasetService.deleteDataset(id);
      setDatasets(prev => prev.filter(dataset => dataset.id !== id));
    } catch (error: any) {
      console.error('Failed to delete dataset:', error);
      // You might want to show an error toast here
    }
  };

  const handleDownload = async (id: string) => {
    try {
      const blob = await datasetService.downloadDataset(id);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `dataset-${id}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error: any) {
      console.error('Failed to download dataset:', error);
      // You might want to show an error toast here
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <motion.h1 
            className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Datasets
          </motion.h1>
          <motion.p 
            className={`mt-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Manage your training and evaluation datasets
          </motion.p>
        </div>
        
        <motion.div 
          className="flex gap-3"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center px-4 py-2 rounded-lg ${
              isDark 
                ? 'bg-white/10 hover:bg-white/15 text-white'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            } transition-colors ${showFilters ? 'ring-2 ring-[#00cbdd]' : ''}`}
          >
            <SlidersHorizontal className="h-4 w-4 mr-2" />
            <span>Filters</span>
          </button>
          
          <button
            onClick={() => setDatasets(mockDatasets)}
            className={`flex items-center px-4 py-2 rounded-lg ${
              isDark 
                ? 'bg-white/10 hover:bg-white/15 text-white'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            } transition-colors`}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            <span>Refresh</span>
          </button>
          
          <button 
            onClick={() => setIsUploading(true)}
            className="flex items-center px-4 py-2 rounded-lg bg-gradient-to-r from-[#00cbdd] to-blue-500 text-white hover:from-[#00b0c0] hover:to-blue-600 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            <span>New Dataset</span>
          </button>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard 
          title="Upload Dataset"
          subtitle="Add your local files to the platform"
        >
          <button 
            onClick={() => setIsUploading(true)}
            className={`w-full h-full p-6 flex flex-col items-center justify-center rounded-xl border-2 border-dashed ${
              isDark 
                ? 'border-gray-700 hover:border-[#00cbdd]/50 text-gray-400 hover:text-[#00cbdd]' 
                : 'border-gray-200 hover:border-[#00cbdd]/50 text-gray-500 hover:text-[#00cbdd]'
            } transition-all duration-300`}
          >
            <Upload className="h-8 w-8 mb-3" />
            <h3 className="font-medium">Upload Files</h3>
            <p className="text-sm mt-1">Drag & drop or click to upload</p>
          </button>
        </DashboardCard>

        <DashboardCard
          title="Cloud Integration" 
          subtitle="Connect with cloud storage providers"
        >
          <button 
            onClick={() => setIsCloudModalOpen(true)}
            className={`w-full h-full p-6 flex flex-col items-center justify-center rounded-xl border-2 border-dashed ${
              isDark 
                ? 'border-gray-700 hover:border-[#00cbdd]/50 text-gray-400 hover:text-[#00cbdd]' 
                : 'border-gray-200 hover:border-[#00cbdd]/50 text-gray-500 hover:text-[#00cbdd]'
            } transition-all duration-300`}
          >
            <Cloud className="h-8 w-8 mb-3" />
            <h3 className="font-medium">Connect Cloud Storage</h3>
            <p className="text-sm mt-1">AWS, GCP, or Azure</p>
          </button>
        </DashboardCard>

        <DashboardCard
          title="Database Connection"
          subtitle="Import data from SQL and NoSQL sources"
        >
          <button 
            onClick={() => setIsDatabaseModalOpen(true)}
            className={`w-full h-full p-6 flex flex-col items-center justify-center rounded-xl border-2 border-dashed ${
              isDark 
                ? 'border-gray-700 hover:border-[#00cbdd]/50 text-gray-400 hover:text-[#00cbdd]' 
                : 'border-gray-200 hover:border-[#00cbdd]/50 text-gray-500 hover:text-[#00cbdd]'
            } transition-all duration-300`}
          >
            <Database className="h-8 w-8 mb-3" />
            <h3 className="font-medium">Connect Database</h3>
            <p className="text-sm mt-1">SQL or NoSQL databases</p>
          </button>
        </DashboardCard>
      </div>

      {/* Search and Filters */}
      <DashboardCard
        title="Search & Filter"
        subtitle="Find and organize your datasets"
      >
        <div className={`relative ${isDark ? 'text-gray-300' : 'text-gray-400'}`}>
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5" />
          <input
            type="text"
            placeholder="Search datasets by name, type, or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full py-3 pl-10 pr-4 rounded-lg border ${
              isDark 
                ? 'bg-[#00052d]/60 border-[#00cbdd]/20 text-white placeholder:text-gray-500'
                : 'bg-gray-50/70 border-gray-200 text-gray-800 placeholder:text-gray-400'
            } focus:outline-none focus:ring-2 focus:ring-[#00cbdd]/40 transition-all duration-200`}
          />
        </div>

        {/* Quick filter buttons */}
        <div className="flex flex-wrap gap-2 mt-4">
          <button
            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
            className={`flex items-center px-3 py-1.5 rounded-lg text-xs ${
              isDark
                ? 'bg-white/10 text-gray-300 hover:bg-white/15'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors`}
          >
            {viewMode === 'grid' ? (
              <><Grid className="h-3 w-3 mr-1" /><span>Grid</span></>
            ) : (
              <><List className="h-3 w-3 mr-1" /><span>List</span></>
            )}
          </button>

          <button
            className={`flex items-center px-3 py-1.5 rounded-lg text-xs ${
              isDark
                ? 'bg-white/10 text-gray-300 hover:bg-white/15'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors`}
          >
            <FileText className="h-3 w-3 mr-1" />
            <span>CSV/JSON</span>
          </button>

          <button
            className={`flex items-center px-3 py-1.5 rounded-lg text-xs ${
              isDark
                ? 'bg-white/10 text-gray-300 hover:bg-white/15'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors`}
          >
            <Cloud className="h-3 w-3 mr-1" />
            <span>Cloud Storage</span>
          </button>

          <button
            className={`flex items-center px-3 py-1.5 rounded-lg text-xs ${
              isDark
                ? 'bg-white/10 text-gray-300 hover:bg-white/15'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors`}
          >
            <Database className="h-3 w-3 mr-1" />
            <span>Databases</span>
          </button>
        </div>
      </DashboardCard>

      {/* Dataset Grid/List */}
      <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
        <AnimatePresence>
          {filteredDatasets.map((dataset, index) => (
            <DatasetCard
              key={dataset.id}
              dataset={dataset}
              isDark={isDark}
              viewMode={viewMode}
              onDelete={handleDelete}
              onDownload={handleDownload}
            />
          ))}
        </AnimatePresence>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {isUploading && (
          <UploadModal
            isOpen={isUploading}
            onClose={() => setIsUploading(false)}
            onUpload={handleUpload}
            isDark={isDark}
          />
        )}
        {isCloudModalOpen && (
          <CloudStorageModal
            isOpen={isCloudModalOpen}
            onClose={() => setIsCloudModalOpen(false)}
            onConnect={handleCloudConnect}
            isDark={isDark}
          />
        )}
        {isDatabaseModalOpen && (
          <DatabaseModal
            isOpen={isDatabaseModalOpen}
            onClose={() => setIsDatabaseModalOpen(false)}
            onConnect={handleDatabaseConnect}
            isDark={isDark}
          />
        )}
      </AnimatePresence>
    </div>
  );
} 